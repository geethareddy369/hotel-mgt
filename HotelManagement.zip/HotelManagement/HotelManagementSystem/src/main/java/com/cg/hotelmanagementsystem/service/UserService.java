package com.cg.hotelmanagementsystem.service;

import java.util.List;

import com.cg.hotelmanagementsystem.dto.Hotels;
import com.cg.hotelmanagementsystem.dto.RoomBooking;
import com.cg.hotelmanagementsystem.dto.Rooms;
import com.cg.hotelmanagementsystem.dto.User;

public interface UserService {
	public Integer addUser(User user);
	public boolean userLogin(Long mobileNumber,String password);
	public List<Hotels> HotelsDisplay(String location);
	public List<Rooms> roomsDisplay(Integer id,String checkInDate,String checkOutDate);
	public Integer bookRoom(RoomBooking roombooking);
	public Integer bookRoom(Long mobileNumber, String indate, String outdate, String location,
			List<Integer> roomNo,Integer id);
}
