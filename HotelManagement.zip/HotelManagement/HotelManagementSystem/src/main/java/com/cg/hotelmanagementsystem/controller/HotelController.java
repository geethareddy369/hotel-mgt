package com.cg.hotelmanagementsystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.hotelmanagementsystem.dto.AddRoom;
import com.cg.hotelmanagementsystem.dto.Admin;
import com.cg.hotelmanagementsystem.dto.Hotels;
import com.cg.hotelmanagementsystem.dto.Rooms;
import com.cg.hotelmanagementsystem.service.HotelService;

@RestController
@RequestMapping("/admincontroller")
@CrossOrigin("http://localhost:4200")
public class HotelController {
	
	@Autowired
	HotelService hotelService;
	
	@PostMapping("/addhotel")
	public Integer addHotel(@RequestBody Hotels hotel) {
		System.out.println("data"+hotel);
		int result=hotelService.addHotel(hotel);
		if(result==1)
			return 1;
		else
		return 2;
	}
	@GetMapping("/getHotelsList")
	public List<Hotels> getAllHotels(){
		return hotelService.getHotelsList();
		
	}
	@DeleteMapping("/deletehotel")
	public Integer deleteHotel(@RequestParam Integer id) {
		int result=hotelService.deleteHotel(id);
		if(result==1)
			return 1;
		else 
			return 2;
	}
	@PostMapping("/addroom")
	public String addRoom(@RequestBody Rooms room) {
		int result=hotelService.addRoom(room);
		if(result==1)
			return "Room added successfully";
		else
		return null;
	}
	@GetMapping("/getRoomsList")
	public List<Rooms> getAllRooms(){
		return hotelService.getRoomsList();
		
	}
	@PostMapping("/addadmin")
	public String addUser(@RequestBody Admin user) {
		int result=hotelService.addAdmin(user);
		if(result==1)
			return "Admin Added Successfully";
		else
			return "Admin Already Existed";
	}
	@GetMapping("/login")
	public boolean userLogin(@RequestParam Long mobileNumber,@RequestParam String password) {
	return 	hotelService.userLogin(mobileNumber, password);
	}
	@PostMapping("/addrooms")
	public  void addRooms(@RequestBody AddRoom room) {
		hotelService.addRoom(room);
	}
	@GetMapping("/viewrooms")
	public List<Rooms> viewRooms(@RequestParam Integer id){
		return hotelService.viewRooms(id);
	}

}
