package com.cg.hotelmanagementsystem.dto;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Rooms {
	@Id
	private Integer roomNumber;
	private Integer price;
	private String amenities;
	private String checkInDate;
	private String checkOutDate;
	
	public String getCheckInDate() {
		return checkInDate;
	}
	public void setCheckInDate(String checkInDate) {
		this.checkInDate = checkInDate;
	}
	public String getCheckOutDate() {
		return checkOutDate;
	}
	public void setCheckOutDate(String checkOutDate) {
		this.checkOutDate = checkOutDate;
	}
	public Integer getRoomNumber() {
		return roomNumber;
	}
	public void setRoomNumber(Integer roomNumber) {
		this.roomNumber = roomNumber;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	public String getAmenities() {
		return amenities;
	}
	public void setAmenities(String amenities) {
		this.amenities = amenities;
	}
	public Rooms() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Rooms(Integer roomNumber, Integer price, String amenities, String checkInDate, String checkOutDate) {
		super();
		this.roomNumber = roomNumber;
		this.price = price;
		this.amenities = amenities;
		this.checkInDate = checkInDate;
		this.checkOutDate = checkOutDate;
	}
	@Override
	public String toString() {
		return "Rooms [roomNumber=" + roomNumber + ", price=" + price + ", amenities=" + amenities + ", checkInDate="
				+ checkInDate + ", checkOutDate=" + checkOutDate + "]";
	}
	

}
