package com.cg.hotelmanagementsystem.dto;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document
public class Admin {
	@Id
	private Long mobileNumber;
	private String userName;
	private String emailId;
	private String Address;
	
	private String password;

	public Long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		this.Address = address;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Admin(Long mobileNumber, String userName, String emailId, String address, String password) {
		super();
		this.mobileNumber = mobileNumber;
		this.userName = userName;
		this.emailId = emailId;
		this.Address = address;
		this.password = password;
	}

	@Override
	public String toString() {
		return "Admin [mobileNumber=" + mobileNumber + ", userName=" + userName + ", emailId=" + emailId + ", Address="
				+ Address + ", password=" + password + "]";
	}
	

}
