package com.cg.hotelmanagementsystem.dto;

public class AddRoom {

private Integer hid;

private Integer roomNumber;
private Integer price;
private String amenities;
public Integer getHid() {
	return hid;
}
public void setHid(Integer hid) {
	this.hid = hid;
}
public Integer getRoomNumber() {
	return roomNumber;
}
public void setRoomNumber(Integer roomNumber) {
	this.roomNumber = roomNumber;
}
public Integer getPrice() {
	return price;
}
public void setPrice(Integer price) {
	this.price = price;
}
public String getAmenities() {
	return amenities;
}
public void setAmenities(String amenities) {
	this.amenities = amenities;
}
public AddRoom() {
	super();
	// TODO Auto-generated constructor stub
}
public AddRoom(Integer hid, Integer roomNumber, Integer price, String amenities) {
	super();
	this.hid = hid;
	this.roomNumber = roomNumber;
	this.price = price;
	this.amenities = amenities;
}
@Override
public String toString() {
	return "AddRoom [hid=" + hid + ", roomNumber=" + roomNumber + ", price=" + price + ", amenities=" + amenities + "]";
}

}
