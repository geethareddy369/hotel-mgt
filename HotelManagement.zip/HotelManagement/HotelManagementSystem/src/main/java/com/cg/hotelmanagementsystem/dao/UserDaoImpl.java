package com.cg.hotelmanagementsystem.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.hotelmanagementsystem.dto.Hotels;
import com.cg.hotelmanagementsystem.dto.RoomBooking;
import com.cg.hotelmanagementsystem.dto.Rooms;
import com.cg.hotelmanagementsystem.dto.User;

@Repository
public class UserDaoImpl implements UserDao{
	
	@Autowired
	MongoTemplate mongoTemplate;

	@Override
	public Integer addUser(User user) {
		// TODO Auto-generated method stub
		mongoTemplate.insert(user);
		return 1;
	}

	@Override
	public boolean userLogin(Long mobileNumber, String password) {
		boolean flag=false;
		User user=mongoTemplate.findOne(Query.query(Criteria.where("mobileNumber").is(mobileNumber)), User.class);
		// TODO Auto-generated method stub
		if(user!=null) {
		if(user.getPassword().equals(password))
		flag=true;
	}
		return flag;
	}

	@Override
	public List<Hotels> HotelsDisplay(String location) {
		List<Hotels> hotelsList=mongoTemplate.findAll(Hotels.class);
		List<Hotels>  newList=new ArrayList<>(); 
		// TODO Auto-generated method stub
		for (Hotels hotels : hotelsList) {
			if(hotels.getLocation().equalsIgnoreCase(location)) {
				newList.add(hotels);
				
			}
			
		}
		return newList;
	}

	@Override
	public List<Rooms> roomsDisplay(Integer id, String checkInDate, String checkOutDate) {
		// TODO Auto-generated method stub
		Hotels hotel=mongoTemplate.findOne(Query.query(Criteria.where("hotelId").is(id)), Hotels.class);
		List<Rooms> list1=new ArrayList<>();
		if(hotel!=null) {
			
			List<Rooms> list=hotel.getRoomsList();
			for (Rooms rooms : list) {
				if(rooms.getCheckInDate()!=null) {
					if(rooms.getCheckOutDate()!=null) {
				
				
				if(!rooms.getCheckInDate().equals(checkInDate)) 
					if(!rooms.getCheckOutDate().equals(checkOutDate)) 
						list1.add(rooms);
					
				
			}
			
		}
				else
				
				list1.add(rooms);
				
				}
			}
		


		return list1;
	}

	@Override
	public Integer bookRoom(Long mobileNumber,String indate,String outdate,String location,List<Integer> roomNo,Integer id) {
		// TODO Auto-generated method stub
		User user=mongoTemplate.findOne(Query.query(Criteria.where("mobileNumber").is(mobileNumber)), User.class);
		List<Integer> rooms=new ArrayList<>();
		rooms=roomNo;
		System.out.println("rooms"+rooms);
		RoomBooking book=new RoomBooking();
		if(user!=null) {
			System.out.println("in user if");
			book.setCheckInDate(indate);
			book.setCheckOutDate(outdate);
			book.setRoomNo(roomNo);
			book.setMobileNumber(user.getMobileNumber());
			book.setHotelId(id);
			book.setPreferredLocation(location);
			mongoTemplate.save(book);
			
		
			
		}
		List<Hotels> hotelsList=mongoTemplate.findAll(Hotels.class);
		List<Hotels>  newList=new ArrayList<>(); 
		// TODO Auto-generated method stub
		for (Hotels hotels : hotelsList) {
			if(hotels.getLocation().equalsIgnoreCase(location)) {
				newList.add(hotels);
			}
			System.out.println("Neew list is"+newList);
			for (Hotels hotel : newList) {
				if(hotel.getHotelId().equals(id)) {
					List<Rooms> roomslist=hotel.getRoomsList();
					for (Rooms rooms2 : roomslist) {
						for(Integer roomid:rooms) {
							if(rooms2.getRoomNumber().equals(roomid)){
							rooms2.setCheckInDate(indate);
							rooms2.setCheckOutDate(outdate);
							mongoTemplate.save(hotel);
							
						}
						
					}
					}
				}
				
			}
				
				
			}
		
		return 1;
	}

	@Override
	public Integer bookRoom(RoomBooking roomBooking) {
		User user=mongoTemplate.findOne(Query.query(Criteria.where("mobileNumber").is(roomBooking.getMobileNumber())), User.class);
		List<Integer> rooms=new ArrayList<>();
		rooms=roomBooking.getRoomNo();
		System.out.println("rooms"+rooms);
		RoomBooking book=new RoomBooking();
		if(user!=null) {
			System.out.println("in user if");
			book.setCheckInDate(roomBooking.getCheckInDate());
			book.setCheckOutDate(roomBooking.getCheckOutDate());
			book.setRoomNo(roomBooking.getRoomNo());
			book.setMobileNumber(user.getMobileNumber());
			book.setHotelId(roomBooking.getHotelId());
			book.setPreferredLocation(roomBooking.getPreferredLocation());
			mongoTemplate.save(book);
			
		
			
		}
		List<Hotels> hotelsList=mongoTemplate.findAll(Hotels.class);
		List<Hotels>  newList=new ArrayList<>(); 
		// TODO Auto-generated method stub
		for (Hotels hotels : hotelsList) {
			if(hotels.getLocation().equalsIgnoreCase(roomBooking.getPreferredLocation())) {
				newList.add(hotels);
			}
			System.out.println("Neew list is"+newList);
			for (Hotels hotel : newList) {
				if(hotel.getHotelId().equals(roomBooking.getHotelId())) {
					List<Rooms> roomslist=hotel.getRoomsList();
					for (Rooms rooms2 : roomslist) {
						for(Integer roomid:rooms) {
							if(rooms2.getRoomNumber().equals(roomid)){
							rooms2.setCheckInDate(roomBooking.getCheckInDate());
							rooms2.setCheckOutDate(roomBooking.getCheckOutDate());
							mongoTemplate.save(hotel);
							
						}
						
					}
					}
				}
				
			}
				
				
			}
		
		return 1;
	}


	
	}
	
