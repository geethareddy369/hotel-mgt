package com.cg.hotelmanagementsystem.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.hotelmanagementsystem.dto.AddRoom;
import com.cg.hotelmanagementsystem.dto.Admin;
import com.cg.hotelmanagementsystem.dto.Hotels;
import com.cg.hotelmanagementsystem.dto.Rooms;

@Repository
public class HotelDaoImpl implements HotelDao{
	@Autowired
	MongoTemplate mongoTemplate;
	@Override
	public Integer addHotel(Hotels hotel) {
		// TODO Auto-generated method stub
		mongoTemplate.insert(hotel);
		return 1;
	}
	@Override
	public List<Hotels> getHotelsList() {
		// TODO Auto-generated method stub
		return mongoTemplate.findAll(Hotels.class);
	}
	@Override
	public Integer deleteHotel(Integer id) {
		Hotels hotel=mongoTemplate.findOne(Query.query(Criteria.where("hotelId").is(id)), Hotels.class);
		// TODO Auto-generated method stub
		mongoTemplate.remove(hotel);
		return 1;
	}
	@Override
	public Integer addRoom(AddRoom room) {
		Hotels hotel=mongoTemplate.findOne(Query.query(Criteria.where("hotelId").is(room.getHid())), Hotels.class);
	     List<Rooms> roomList=hotel.getRoomsList();
	     Rooms rooom=new Rooms();
	     rooom.setRoomNumber(room.getRoomNumber());
	     rooom.setPrice(room.getPrice());
	     rooom.setAmenities(room.getAmenities());
	     roomList.add(rooom);
	     hotel.setRoomsList(roomList);
	     
	     		
		
		mongoTemplate.save(hotel);
	
	
		
	
	return 1;
	}
	@Override
	public List<Rooms> getRoomsList() {
		// TODO Auto-generated method stub
		return mongoTemplate.findAll(Rooms.class);
	}
	@Override
	public boolean userLogin(Long mobileNumber, String password) {
		boolean flag=false;
		Admin admin=mongoTemplate.findOne(Query.query(Criteria.where("mobileNumber").is(mobileNumber)), Admin.class);
		// TODO Auto-generated method stub
		if(admin!=null) {
		if(admin.getPassword().equals(password))
		flag=true;
	}
	

	return flag;
	}
	@Override
	public Integer addAdmin(Admin user) {
		mongoTemplate.insert(user);
		return 1;
	}
	@Override
	public Integer addRoom(Rooms room) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<Rooms> viewRooms(Integer id) {
		// TODO Auto-generated method stub
		Hotels hotel=mongoTemplate.findOne(Query.query(Criteria.where("hotelId").is(id)), Hotels.class);
		List<Rooms> roomList=hotel.getRoomsList();
		return roomList;
	}
}
