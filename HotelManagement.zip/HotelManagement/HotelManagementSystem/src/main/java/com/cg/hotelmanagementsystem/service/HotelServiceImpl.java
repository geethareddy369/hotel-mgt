package com.cg.hotelmanagementsystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hotelmanagementsystem.dao.HotelDao;
import com.cg.hotelmanagementsystem.dto.AddRoom;
import com.cg.hotelmanagementsystem.dto.Admin;
import com.cg.hotelmanagementsystem.dto.Hotels;
import com.cg.hotelmanagementsystem.dto.Rooms;

@Service
public class HotelServiceImpl implements HotelService{
	@Autowired
	HotelDao hotelDao;

	@Override
	public Integer addHotel(Hotels hotel) {
		// TODO Auto-generated method stub
		return hotelDao.addHotel(hotel);
	}

	@Override
	public List<Hotels> getHotelsList() {
		// TODO Auto-generated method stub
		return hotelDao.getHotelsList();
	}

	@Override
	public Integer deleteHotel(Integer id) {
		// TODO Auto-generated method stub
		return hotelDao.deleteHotel(id);
	}

	@Override
	public Integer addRoom(Rooms room) {
		// TODO Auto-generated method stub
		return hotelDao.addRoom(room);
	}

	@Override
	public List<Rooms> getRoomsList() {
		// TODO Auto-generated method stub
		return hotelDao.getRoomsList();
	}

	@Override
	public boolean userLogin(Long mobileNumber, String password) {
		// TODO Auto-generated method stub
		return hotelDao.userLogin(mobileNumber,password);
	}

	@Override
	public Integer addAdmin(Admin user) {
		// TODO Auto-generated method stub
		return hotelDao.addAdmin(user);
	}

	@Override
	public Integer addRoom(AddRoom room) {
		// TODO Auto-generated method stub
		return hotelDao.addRoom(room);
	}

	@Override
	public List<Rooms> viewRooms(Integer id) {
		// TODO Auto-generated method stub
		return hotelDao.viewRooms(id);
	}
	

}
