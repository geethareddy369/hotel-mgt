import { Component, OnInit } from '@angular/core';
import { HotelService } from '../hotel.service';

@Component({
  selector: 'app-rooms-display',
  templateUrl: './rooms-display.component.html',
  styleUrls: ['./rooms-display.component.css']
})
export class RoomsDisplayComponent implements OnInit {
  data:any=[];
  message:any;

  constructor(private service:HotelService) { }
  book(roomNumber){
    this.service.bookRoom(roomNumber).subscribe(result=>{this.message=result;
    if(this.message==1)
    alert("room booked successfully");
    })

  }

  ngOnInit() {
    this.service.roomsDisplay(localStorage.getItem("hotelid"),localStorage.getItem("indate"),localStorage.getItem("outdate")).subscribe(
      result=>{this.data=result;
        })
  }

}
