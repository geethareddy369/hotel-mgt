import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './user-home/home.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './Register/register.component';
import { LogoutComponent } from './logout/logout.component';
import { HotelHomeComponent } from './Hotel-Home/hotel-home.component';
import { HotelDisplayComponent } from './Hotel-display/hotel-display.component';
import { RoomsDisplayComponent } from './Rooms-display/rooms-display.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { ViewhotelsComponent } from './viewhotels/viewhotels.component';
import { AddhotelComponent } from './addHotel/addhotel.component';
import { ViewroomsComponent } from './viewrooms/viewrooms.component';
import { AddroomComponent } from './addroom/addroom.component';


const routes: Routes = [
  {path:'home',component:HomeComponent},
  {path:'login',component:LoginComponent},
  {path:'register',component:RegisterComponent},
  {path:'logout',component:LogoutComponent},
  {path:'hotelhome',component:HotelHomeComponent},
  {path:'hoteldisplay',component:HotelDisplayComponent},
  {path:'roomsdisplay',component:RoomsDisplayComponent},
  {path:'adminhome',component:AdminHomeComponent},
  {path:'viewhotels',component:ViewhotelsComponent},
  {path:'addhotel',component:AddhotelComponent},
  {path:'viewrooms',component:ViewroomsComponent},
  {path:'addroom',component:AddroomComponent},
  {path:'',component:HomeComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
