import { Component, OnInit } from '@angular/core';
import { HotelService } from '../hotel.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  data:any;
  mobile:any;
  pwd:any;
  data1:any;

  constructor(private service:HotelService,private router:Router) { }
  onSubmit(userForm){
    console.log("role is"+userForm.role);
    if(userForm.role=="admin"){
      console.log("admin");
      this.service.adminLogin(userForm.mobile,userForm.password).subscribe(result=>{this.data1=result
      console.log("checking"+this.data1);
      if(this.data1==true){
        console.log("admin navigation");
        this.router.navigate(['/adminhome']);
      }
      else
      alert("you are not admin")
    });
    }
    else{
    
    this.service.check(userForm.mobile,userForm.password).subscribe(result=>{
      this.data=result;
      if(this.data==true){
      localStorage.setItem("userMobile",userForm.mobile);
      console.log("valid user");
      this.router.navigate(['/hotelhome']);
    }

        else
        alert("enter correct credintials");

    
    });

  }
  }

  ngOnInit() {
  }

}
